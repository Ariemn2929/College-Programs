# This program displays an empty window.

import tkinter

def main():
    # Create the main window widget.
    main_window = tkinter.Tk()

    # Enter the tkinter main loop.
    tkinter.mainloop()

# Call the main function.
main()
