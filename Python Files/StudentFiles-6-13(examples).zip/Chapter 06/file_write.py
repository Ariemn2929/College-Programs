# This program writes three lines of data
# to a file.

def writeLn():
    # Open a file named philosophers.txt.
    print('This will open Philosophers file \n and add three names.\n')
    outfile = open('philosophers.txt', 'a')

    # Write the names of three philosphers
    # to the file.
    outfile.write('John Locke\n')
    outfile.write('David Hume\n')
    outfile.write('Edmund Burke\n')

    # Close the file.
    outfile.close()

# Call the main function.
writeLn()
