# This program adds coffee inventory records to
# the coffee.txt file.

def main():
    another = 'y'       #this controls loop
  
    coffee_file = open('coffee.txt', 'a')       # Open the coffee.txt append mode.

    # Add records to the file.
    while another == 'y' or another == 'Y':
        print('Enter the following coffee data:')
        descr = input('Description: ')
        qty = int(input('Quantity (in pounds): '))

        coffee_file.write(descr + '\n')
        coffee_file.write(str(qty) + '\n')

        print('Do you want to add another record?')
        another = input('Y = yes, anything else = no: ')

    coffee_file.close()
    print('Data appended to coffee.txt.')

main()

        
