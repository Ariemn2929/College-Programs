def main():
    even_numbers = [2,4,6,8,10,12]
    print (even_numbers,'\n')

    names=['Joe', 'Molly', "Steve", "Adam", "Susan"]
    print(names,'\n')

    info=['Alice', 33,1550.87]
    print(info,'\n')

    repeat()

def repeat():
    numbers = [1] * 5
    print(numbers,'\n')

    numb = [1,2,3]*5
    print (numb)

    seara=[99,100,200,300]
    for n in seara:
        print(n)
main()
