# This program demonstrates the insert method.

def main():
    # Create a list with some names.
    names = ['James', 'Kathryn', 'Bill']

    # Display the list.
    print('The list before the insert:')
    print(names)

    # Insert a new name at element 0.
    names.insert(-1, 'Joe')

    # Display the list again.
    print('The list after the insert:')
    print(names)

    findItem(names)

def findItem(names):
    fname=input("what name are you looking for? ")
    answr=fname in names
    print(answr)
main()
