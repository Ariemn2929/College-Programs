max=5
def main():
     total=0.0
     number=.5
     while number>0:
          for counter in range(10):
               number=int(input('Enter a number: '))
               total= total+number
               print(total)

main()
